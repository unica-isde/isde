class Rectangle:
    def __init__(self, a, b):
        # I'm using the setters!
        self.a = a
        self.b = b

    @property
    def a(self):
        return self._a

    @a.setter
    def a(self, a):
        self._a = a

    @property
    def b(self):
        return self._b

    @b.setter
    def b(self, b):
        self._b = b


class Square(Rectangle):
    def __init__(self, a, b=None):
        super().__init__(a,a)


    @property
    def a(self):
        #return super().a
        return self._a

    @a.setter
    def a(self, a):
        self._a = a
        self._b = a

    @property
    def b(self):
        return super().b

    @b.setter
    def b(self, b):
        self._a = b
        self._b = b



print('rectangle')
r1 = Rectangle(1, 2)
print(r1.a, r1.b)
r1.a = 10
print(r1.a, r1.b)

print('square')
s1 = Square(2)
print(s1.a, s1.b)
s1.a = 10
print(s1.a, s1.b)
s1.b = 20
print(s1.a, s1.b)
