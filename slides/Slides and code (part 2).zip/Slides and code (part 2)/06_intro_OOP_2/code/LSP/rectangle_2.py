class Rectangle:
    def __init__(self, a, b):
        # I'm using the setters!
        self.a = a
        self.b = b

    @property
    def a(self):
        return self._a

    @a.setter
    def a(self, a):
        self._a = a

    @property
    def b(self):
        return self._b

    @b.setter
    def b(self, b):
        self._b = b


class Square(Rectangle):
    def __init__(self, a, b=None):
        super().__init__(a,a)

    @property
    def a(self):
        #return self._a
        return super().a

    @a.setter
    def a(self, a):
        self._a = a
        self._b = a

    @property
    def b(self):
        return super().b

    @b.setter
    def b(self, b):
        self._a = b
        self._b = b


def f_consistency(r, v1, v2):
    r.a = v1
    r.b = v2
    print('debug')
    print(r.a, r.b)
    print(r.a * r.b == v1 * v2)



print('rectangle')
r1 = Rectangle(1, 2)
print('---')
print(r1.a, r1.b)
r1.a = 10
print(r1.a, r1.b)

f_consistency(r1, 7, 8) ## TRUE

print('square')
s1 = Square(2)
print(s1.a, s1.b) #2,2
s1.a=10
print(s1.a, s1.b) #10,10

# f_consistency(s1, 7, 8)
