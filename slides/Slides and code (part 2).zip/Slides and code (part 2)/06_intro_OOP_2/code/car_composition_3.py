import copy

class Engine():
    def __init__(self, displacement=1000):
        self.displacement = displacement


class Wheel():
    def __init__(self, pressure=10):
        self.pressure = pressure


class Seat():
    def __init__(self, color=1):  # 1, 2, 3
        self.color = color


class Car():
    def __init__(self, displacement=1000, n_wheels=4, pressure=10, n_seats=5):

        self.engine = Engine(displacement)
        self.wheels = [Wheel(pressure) for i in range(n_wheels)]
        self.seats = [Seat() for i in range(n_seats)]

    @property
    def displacement(self):
        return self.engine.displacement

    @property
    def wheels_pressure(self):
        return [el.pressure for el in self.wheels]

    @property
    def n_seats(self):
            return len(self.seats)



if __name__ == '__main__':

    car1 = Car(2000, 4, 7)
    car2 = Car(2000, 4, 7)


    print('displacement:', car1.displacement)
    print('wheel pressure:', car1.wheels_pressure)
    print('n seats:', car1.n_seats)


    print('\nWHEEL - PRESSURE')
    print('car 1:', car1.wheels[0].pressure)
    print('car 2:', car2.wheels[0].pressure)

    car1.wheels[0].pressure = 5

    print('\nWHEEL - PRESSURE after that we change the pressure of WHEEL 0 - CAR 1')
    print('car 1:', car1.wheels[0].pressure)
    print('car 2:', car2.wheels[0].pressure)
