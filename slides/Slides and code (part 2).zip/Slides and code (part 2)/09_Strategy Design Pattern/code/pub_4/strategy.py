
def compute_price_normal(value):
    return value


def compute_price_happy_hour(value):
    # (50 % discount)
    discount = 0.5
    return value * discount
