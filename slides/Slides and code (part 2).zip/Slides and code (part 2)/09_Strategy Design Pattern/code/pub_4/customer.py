class Customer():
    def __init__(self, f_price):
        self.cost = 0
        self.compute_price = f_price

    def print_bill(self):
        print(self.cost)

    def add_drink(self, n, unit_cost):
        self.cost += self.compute_price(n * unit_cost)
