

from utility import create_palindrome, is_palindrome


list_of_strings = ['A',
                   'AA', 'AX',
                   'ABA', 'AAX', 'AXY',
                   'ABBA', 'ABAX', 'AAXY', 'AXYW',
                   'ABCBA', 'ABBAX', 'ABAXY', 'AAXYW', 'AXYWZ']


# test create_palindrome
print('\nPALINDROME\n')
for s in list_of_strings:
    s_pal = create_palindrome(s)
    print(s, '->', s_pal)
    if not is_palindrome(s_pal):
        print('ERROR! The string is not palindrome!')