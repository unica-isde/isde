# package_02

Write a package **`mypkg`** that contains `module1`, with a function `bar()`, and `module2`, with a function `_secret()`. Each function must print its name.

When you import the package **`mypkg`**, 
- the package must print a welcome message and it must initialize the list `mypkg.myList=['a','b', 'c']`
- modules `module1` and `module2` are imported automatically.

Write a client (mainprogram) that use the `bar()` and `_secret().

