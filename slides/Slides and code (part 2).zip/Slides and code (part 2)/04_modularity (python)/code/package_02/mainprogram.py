# mainprogram.py

import mypkg

#mypkg.module1.bar()
#mypkg.module2.foo()

print (dir())
