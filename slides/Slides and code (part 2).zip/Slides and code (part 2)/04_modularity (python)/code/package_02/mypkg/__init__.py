#!/usr/bin/env python

print('this code will be executed automatically!')
