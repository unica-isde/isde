def foo():
    print('Module 2 - foo function')
