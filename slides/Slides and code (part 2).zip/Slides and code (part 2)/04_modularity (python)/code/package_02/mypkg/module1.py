def bar():
    print('Module 1 - bar function')