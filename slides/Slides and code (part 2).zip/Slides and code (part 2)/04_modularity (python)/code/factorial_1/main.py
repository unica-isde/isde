#MAIN
import fact

print(fact.factorial(0))
print(fact.factorial(1))
print(fact.factorial(2))
print(fact.factorial(3))
